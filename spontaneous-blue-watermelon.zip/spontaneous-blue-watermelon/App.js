
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#f7dce8">
<title>Bloom</title>
<style>
:root {
  --pink:#f7dce8;
  --pink2:#f1c4d7;
  --deep:#bd668f;
  --ink:#594451;
  --muted:#987d8c;
  --paper:#fff9fc;
  --line:#f1e2e9;
  --white:#fff;
}
* {box-sizing:border-box}
body {
  margin:0;
  background:var(--paper);
  color:var(--ink);
  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
  padding-bottom:100px;
}
header {
  position:sticky;
  top:0;
  z-index:5;
  background:#fff;
  display:flex;
  align-items:center;
  justify-content:space-between;
  padding:15px 19px;
  border-bottom:1px solid var(--line);
}
.logo {font-weight:800;font-size:24px;color:var(--deep);letter-spacing:-1px}
.date {font-size:12px;color:var(--muted)}
main {max-width:720px;margin:auto;padding:0 17px 30px}
.intro {padding:25px 3px 17px}
.eyebrow {font-size:10px;letter-spacing:3px;color:var(--deep);font-weight:800}
h1 {font-size:29px;margin:7px 0 5px;letter-spacing:-.8px}
h2 {font-size:18px;margin:5px 0 10px}
h3 {font-size:15px;margin:12px 0 7px}
p {line-height:1.5}
.sub,.muted {color:var(--muted);font-size:13px;line-height:1.5}
.card {
  background:#fff;
  border:1px solid var(--line);
  border-radius:21px;
  padding:18px;
  margin-bottom:14px;
  box-shadow:0 4px 15px #7e49600a;
}
.hero {
  background:linear-gradient(145deg,#f8dce8,#fbeaf1);
  text-align:center;
  padding:25px 20px;
}
.flower {font-size:42px;color:var(--deep)}
button {
  border:0;
  border-radius:13px;
  padding:11px 15px;
  background:var(--deep);
  color:white;
  font-weight:700;
  font-size:13px;
  cursor:pointer;
}
button.soft {background:var(--pink);color:var(--ink)}
button.outline {background:white;color:var(--deep);border:1px solid var(--pink2)}
button.small {padding:7px 10px;font-size:12px}
button:disabled {opacity:.45}
.row {display:flex;align-items:center;gap:9px}
.between {justify-content:space-between}
.wrap {flex-wrap:wrap}
input,textarea,select {
  font:inherit;
  color:var(--ink);
  background:var(--paper);
  border:1px solid var(--line);
  border-radius:12px;
  padding:11px;
  width:100%;
  outline-color:var(--pink2);
}
label {display:block;font-size:12px;color:var(--muted);margin:10px 0 5px}
.field {margin-top:10px}
.grid {display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}
.task {
  display:flex;
  align-items:flex-start;
  gap:10px;
  padding:12px 1px;
  border-bottom:1px solid #f6edf1;
}
.task:last-child {border-bottom:0}
.check {
  width:23px;height:23px;min-width:23px;
  padding:0;
  border:1.7px solid var(--pink2);
  border-radius:50%;
  background:white;
  color:white;
  display:grid;
  place-items:center;
}
.task.done .check {background:var(--deep);border-color:var(--deep)}
.task.done .taskname {text-decoration:line-through;color:#b49aa8}
.taskname {flex:1;font-size:14px;line-height:1.4}
.tasktime {font-size:11px;color:var(--muted);min-width:65px}
.progress-number {font-size:29px;font-weight:800;color:var(--deep);margin:7px 0}
.track {height:9px;background:#f5e9ef;border-radius:20px;overflow:hidden;margin:9px 0}
.fill {height:100%;background:var(--deep);border-radius:20px;width:0}
nav {
  position:fixed;
  bottom:0;left:0;right:0;
  z-index:10;
  background:#fff;
  border-top:1px solid var(--line);
  display:flex;
  justify-content:space-around;
  padding:9px 3px calc(8px + env(safe-area-inset-bottom));
}
nav button {
  background:transparent;
  color:#a88f9d;
  padding:4px 2px;
  flex:1;
  font-size:10px;
  font-weight:600;
}
nav button span {display:block;font-size:20px;margin-bottom:3px}
nav button.active {color:var(--deep)}
.pill {
  display:inline-block;
  padding:5px 9px;
  border-radius:20px;
  background:#fff0f6;
  color:var(--deep);
  font-size:11px;
  font-weight:700;
}
.notice {
  background:#fff5f9;
  border:1px solid var(--pink);
  padding:13px;
  border-radius:14px;
  color:var(--muted);
  font-size:12px;
  line-height:1.5;
}
.event {
  padding:12px 0;
  border-bottom:1px solid var(--line);
}
.event:last-child {border-bottom:0}
.history {
  padding:12px 0;
  border-bottom:1px solid var(--line);
  font-size:13px;
}
.theme-tile {
  min-height:95px;
  border:2px solid transparent;
  border-radius:17px;
  padding:12px;
  color:var(--ink);
  text-align:left;
}
.theme-tile.selected {border-color:var(--deep)}
.theme-tile strong {display:block;margin-bottom:5px}
.theme-jan {background:linear-gradient(135deg,#c9c9ef,#f4d5e8)}
.theme-feb {background:linear-gradient(135deg,#f7c8d9,#ffe9ee)}
.theme-mar {background:linear-gradient(135deg,#c8e9e2,#d8e6fa)}
.theme-apr {background:linear-gradient(135deg,#f8d9e9,#e1efd6)}
.theme-may {background:linear-gradient(135deg,#d5eacb,#f8e6a9)}
.theme-jun {background:linear-gradient(135deg,#bce8ef,#f9e4bf)}
.theme-jul {background:linear-gradient(135deg,#d4dafa,#f8d4df)}
.theme-aug {background:linear-gradient(135deg,#f7e6a9,#f8d6c5)}
.theme-sep {background:linear-gradient(135deg,#d9e4f6,#f4d8bd)}
.theme-oct {background:linear-gradient(135deg,#e7c7ed,#f5d3b4)}
.theme-nov {background:linear-gradient(135deg,#e9c8ae,#f2dfc8)}
.theme-dec {background:linear-gradient(135deg,#c9e1ef,#f1e2ef)}
.month-banner {
  border-radius:18px;
  padding:20px;
  margin-bottom:14px;
  background:linear-gradient(135deg,#f8dce8,#eee0f7);
}
.hidden {display:none!important}
@media(min-width:600px) {
  main {padding-left:24px;padding-right:24px}
  h1 {font-size:34px}
}
</style>
</head>
<body>
<header>
  <div class="logo">bloom ✿</div>
  <div class="date" id="today"></div>
</header>
<main id="app"></main>
<nav>
  <button data-tab="Home" class="active"><span>⌂</span>Home</button>
  <button data-tab="Routines"><span>♡</span>Routines</button>
  <button data-tab="Cleaning"><span>✿</span>Cleaning</button>
  <button data-tab="Calendar"><span>▦</span>Calendar</button>
  <button data-tab="Themes"><span>❀</span>Themes</button>
</nav>
<script>
const KEY = "bloom-personal-v2";
const days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const months = ["January","February","March","April","May","June","July","August","September","October","November","December"];

const roomTasks = {
  Monday: {
    name:"Kitchen",
    tasks:[
      "Clear counters","Wash dishes","Clean microwave","Clean air fryer",
      "Clean inside and top of refrigerator","Clean inside dishwasher",
      "Take out trash","Disinfect trash cans","Clean microwave cart",
      "Clean burner plates and under stovetop","Replace wax melts",
      "Spin mop floors and walls","Clean mop bucket","Steam mop floors"
    ]
  },
  Tuesday: {
    name:"Bathroom",
    tasks:[
      "Clean mirrors","Clean sink and counter","Clean shelf","Clean toilet",
      "Scrub shower","Mop floors and walls","Disinfect door knobs and handles",
      "Empty trash","Replace wax melts"
    ]
  },
  Wednesday: {
    name:"Living room",
    tasks:[
      "Pick up floors","Vacuum couches and underneath",
      "Clean AC filter","Dust shelves","Clean windows and blinds",
      "Clean Coco's house","Vacuum floor","Mop walls",
      "Clean baseboards and heater"
    ]
  },
  Thursday: {
    name:"Bedrooms",
    tasks:[
      "Vacuum beds and change sheets","Wipe bed frames and furniture",
      "Organize closets","Clean AC filter","Organize toys","Declutter",
      "Clean windows","Mop walls","Disinfect door knobs"
    ]
  }
};

function makeRoutine(date) {
  const day = days[date.getDay()];
  const t = [];
  const add = (time,title) => t.push({time,title});
  add("8:30 AM","Wake up");
  add("8:30 AM","Drink 16 oz of water");
  add("8:30 AM","Bathroom");
  add("8:30 AM","Brush teeth");
  add("8:30 AM","Get dressed");
  add("8:30 AM","Get Dakota dressed");
  add("8:30 AM","Make breakfast");
  add("9:00 AM","Eat breakfast together");
  add("9:00 AM","Pick up after breakfast");

  if(day!=="Tuesday" && day!=="Thursday") {
    add("10:00 AM","Educational play with Dakota");
  }

  if(day==="Thursday") {
    add("9:30 AM","Do my hair");
    add("9:45 AM","Daily cleaning: Make beds");
    add("9:45 AM","Daily cleaning: Wipe down toilet");
    add("10:30 AM","OT appointment");
  } else if(day==="Tuesday") {
    add("9:45 AM","OT appointment");
    add("10:30 AM","Do my hair");
    add("11:00 AM","Daily cleaning: Make beds");
    add("11:00 AM","Daily cleaning: Wipe down toilet");
  } else {
    add("10:30 AM","Do my hair");
    add("11:00 AM","Daily cleaning: Make beds");
    add("11:00 AM","Daily cleaning: Wipe down toilet");
  }

  add("12:00 PM","Make and eat lunch");
  add("1:00 PM","Go outside if weather is nice, otherwise indoor play");
  add("1:30 PM","Dakota's independent play");
  add("1:30 PM","Exercise");
  if(roomTasks[day]) {
    add("2:15 PM","Clean room of the day: "+roomTasks[day].name);
  }
  add("2:15 PM","Dakota's screen time");
  add("3:30 PM","Outside time or indoor play with Dakota");
  add("3:30 PM","My screen time");
  add("5:30 PM","Make dinner");
  add("6:00 PM","Eat dinner together");
  add("6:00 PM","Clean up dinner mess");
  add("6:45 PM","Wash Coco's hair if it is hair-wash day, otherwise play until bath");
  add("6:45 PM","Daily cleaning: One load of laundry");
  add("7:30 PM","Daily cleaning: Make beds");
  add("7:30 PM","Daily cleaning: Ensure living room is picked up");
  add("7:30 PM","Bath time preparation");
  add("7:30 PM","Coco's bath time");
  add("8:15 PM","Lotion, pajamas, brush hair");
  add("8:15 PM","Bedtime snack and bedtime gummies");
  add("8:30 PM","Brush Coco's teeth");
  add("8:30 PM","Quiet time");
  add("9:00 PM","Coco's bedtime");
  add("9:30 PM","My shower");
  add("10:30 PM","Lotion and pajamas");
  add("10:30 PM","Skincare and brush teeth");
  add("10:30 PM","Blow dry hair");
  add("11:00 PM","Get in bed");
  add("11:00 PM","Aim to be asleep by 1:00 AM");
  return t;
}

let state = {
  tab:"Home",
  selectedDate:localDateKey(new Date()),
  routines:{},
  cleaning:{},
  history:[],
  events:[],
  theme:new Date().getMonth()
};

function localDateKey(d) {
  const y=d.getFullYear();
  const m=String(d.getMonth()+1).padStart(2,"0");
  const day=String(d.getDate()).padStart(2,"0");
  return `${y}-${m}-${day}`;
}
function load() {
  try {
    const saved=JSON.parse(localStorage.getItem(KEY)||"null");
    if(saved) state={...state,...saved};
  } catch(e) {}
}
function save() {
  localStorage.setItem(KEY,JSON.stringify(state));
}
function selectedDate() {
  return new Date(state.selectedDate+"T12:00:00");
}
function selectedDay() {
  return days[selectedDate().getDay()];
}
function routineForDate() {
  const key=state.selectedDate;
  if(!state.routines[key]) {
    state.routines[key]=makeRoutine(selectedDate()).map((x,i)=>({...x,id:i,done:false}));
    save();
  }
  return state.routines[key];
}
function cleaningForDate() {
  const key=state.selectedDate;
  if(!state.cleaning[key]) {
    state.cleaning[key]=[
      "Make beds",
      "Wash dishes, wipe sink and wipe counters",
      "Wipe down toilet with Clorox wipes",
      "Ensure living room is picked up",
      "One load of laundry"
    ].map((title,i)=>({id:i,title,done:false}));
    save();
  }
  return state.cleaning[key];
}
function escapeHTML(s) {
  return String(s).replace(/[&<>"']/g,c=>({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
}
function intro(title,sub) {
  return `<section class="intro"><div class="eyebrow">YOUR LITTLE CORNER</div><h1>${title}</h1><p class="sub">${sub}</p></section>`;
}
function progress(items) {
  const done=items.filter(x=>x.done).length;
  const pct=items.length?Math.round(done/items.length*100):0;
  return `<div class="progress-number">${pct}%</div>
  <div class="track"><div class="fill" style="width:${pct}%"></div></div>
  <div class="muted">${done} of ${items.length} completed</div>`;
}
function taskList(items,type) {
  return items.map(x=>`
    <div class="task ${x.done?"done":""}">
      <button class="check" data-check="${type}" data-id="${x.id}">${x.done?"✓":""}</button>
      ${x.time?`<span class="tasktime">${escapeHTML(x.time)}</span>`:""}
      <div class="taskname">${escapeHTML(x.title)}</div>
    </div>`).join("");
}
function currentRoom() {
  return roomTasks[selectedDay()];
}
function home() {
  const tasks=routineForDate();
  const done=tasks.filter(t=>t.done).length;
  return intro("A fresh start","Your space, your pace.")+
  `<section class="month-banner">
    <div class="eyebrow">${months[state.theme].toUpperCase()} THEME</div>
    <h2>Welcome to Bloom ✿</h2>
    <p class="muted">A little progress is still progress</p>
    <button class="soft" data-go="Themes">Explore monthly themes</button>
  </section>
  <section class="card">
    <div class="row between"><h2>Today's progress</h2><span class="pill">${done}/${tasks.length}</span></div>
    ${progress(tasks)}
    <button class="soft" data-go="Routines">Open today's routine</button>
  </section>
  <section class="card">
    <h2>Daily cleaning</h2>
    ${progress(cleaningForDate())}
    <button class="soft" data-go="Cleaning">Open cleaning checklist</button>
  </section>
  <section class="card">
    <h2>Coming up</h2>
    ${upcomingEvents()}
    <button class="outline" data-go="Calendar">Open calendar</button>
  </section>`;
}
function routines() {
  const items=routineForDate();
  return intro("My routines","A little structure for every day.")+
  `<section class="card">
    <label for="routineDate">Choose a day</label>
    <input type="date" id="routineDate" value="${state.selectedDate}">
    <div class="row between" style="margin-top:14px">
      <h2>${escapeHTML(selectedDate().toLocaleDateString(undefined,{weekday:"long",month:"long",day:"numeric"}))}</h2>
      <span class="pill">${items.filter(x=>x.done).length}/${items.length}</span>
    </div>
    ${progress(items)}
    ${taskList(items,"routine")}
    <button style="width:100%;margin-top:14px" data-archive>Save this day to history</button>
  </section>
  <section class="card">
    <h2>Past days</h2>
    ${historyMarkup()}
  </section>`;
}
function cleaning() {
  const daily=cleaningForDate();
  const room=currentRoom();
  const roomItems=room?room.tasks.map((title,i)=>({
    id:i,title,done:!!(state.cleaning[state.selectedDate+"-room"]||[])[i]?.done
  })):[];
  if(room && !state.cleaning[state.selectedDate+"-room"]) {
    state.cleaning[state.selectedDate+"-room"]=roomItems;
    save();
  }
  const roomList=room?state.cleaning[state.selectedDate+"-room"]:[];
  return intro("Cleaning schedule","Little steps make a cozy home.")+
  `<section class="card">
    <label for="cleanDate">Choose a day</label>
    <input type="date" id="cleanDate" value="${state.selectedDate}">
    <h2>Daily cleaning</h2>
    <p class="muted">These five tasks repeat every day</p>
    ${progress(daily)}
    ${taskList(daily,"daily")}
  </section>
  ${room?`<section class="card">
    <div class="row between"><h2>${room.name} day</h2><span class="pill">${selectedDay()}</span></div>
    <p class="muted">Your weekly room checklist</p>
    ${progress(roomList)}
    ${taskList(roomList,"room")}
  </section>`:
  `<section class="card"><h2>Easy day</h2><p class="muted">No room-specific cleaning scheduled today. Just your daily checklist!</p></section>`}
  <section class="card">
    <h2>Weekly cleaning plan</h2>
    ${Object.entries(roomTasks).map(([day,r])=>`
      <div class="event"><strong>${day}</strong><div class="muted">${r.name}</div></div>
    `).join("")}
    <p class="muted">Friday, Saturday and Sunday are daily-cleaning-only days</p>
  </section>`;
}
function eventList() {
  const fixed=[
    {date:"weekly",day:"Tuesday",time:"9:45–10:15 AM",title:"OT appointment"},
    {date:"weekly",day:"Thursday",time:"10:30–11:00 AM",title:"OT appointment"}
  ];
  const chosen=selectedDate();
  const list=[];
  if(chosen.getDay()===2) list.push(fixed[0]);
  if(chosen.getDay()===4) list.push(fixed[1]);
  state.events.filter(e=>e.date===state.selectedDate).forEach(e=>list.push(e));
  return list;
}
function upcomingEvents() {
  const list=eventList();
  if(!list.length) return `<p class="muted">Nothing scheduled for this day</p>`;
  return list.map(e=>`<div class="event"><strong>${escapeHTML(e.title)}</strong><div class="muted">${escapeHTML(e.time)}</div></div>`).join("");
}
function calendar() {
  const events=eventList();
  return intro("Calendar","Appointments and important days.")+
  `<section class="card">
    <label for="calendarDate">Select a date</label>
    <input type="date" id="calendarDate" value="${state.selectedDate}">
    <h2 style="margin-top:16px">${escapeHTML(selectedDate().toLocaleDateString(undefined,{weekday:"long",month:"long",day:"numeric",year:"numeric"}))}</h2>
    ${events.length?events.map(e=>`
      <div class="event"><div class="row between"><strong>${escapeHTML(e.title)}</strong>
      ${e.id?`<button class="small soft" data-delete-event="${e.id}">Remove</button>`:""}
      </div><div class="muted">${escapeHTML(e.time)}</div></div>
    `).join(""):`<p class="muted">No appointments or events saved for this day.</p>`}
  </section>
  <section class="card">
    <h2>Add an event</h2>
    <form id="eventForm">
      <label>Event name</label>
      <input id="eventTitle" maxlength="80" required placeholder="Example: Dentist appointment">
      <label>Date</label>
      <input id="eventDate" type="date" value="${state.selectedDate}" required>
      <label>Time</label>
      <input id="eventTime" placeholder="Example: 2:00 PM">
      <button style="width:100%;margin-top:13px">Add to calendar</button>
    </form>
  </section>
  <section class="card">
    <h2>Weekly recurring appointments</h2>
    <div class="event"><strong>Tuesday</strong><div class="muted">OT · 9:45–10:15 AM</div></div>
    <div class="event"><strong>Thursday</strong><div class="muted">OT · 10:30–11:00 AM</div></div>
    <p class="muted">These appointments appear automatically on their scheduled days</p>
  </section>`;
}
function themes() {
  const themeClasses=["theme-jan","theme-feb","theme-mar","theme-apr","theme-may","theme-jun","theme-jul","theme-aug","theme-sep","theme-oct","theme-nov","theme-dec"];
  const decorations=["☁️ ✨","💕 💌","🌧️ 🌷","🦋 🌼","🐝 🌻","🐚 🌊","☀️ ⭐","🍋 🌻","📚 🍎","🎃 👻","🍂 🧡","❄️ 🎄"];
  return intro("Monthly themes","A new little look for every season.")+
  `<section class="card">
    <div class="notice">Choose a month to preview its seasonal color palette. Your original planner artwork can be added as the decorative background when the individual images are available.</div>
    <div class="grid" style="margin-top:14px">
      ${months.map((m,i)=>`
        <button class="theme-tile ${themeClasses[i]} ${state.theme===i?"selected":""}" data-theme="${i}">
          <strong>${m}</strong>${decorations[i]}
          ${state.theme===i?'<div class="muted">Selected</div>':""}
        </button>
      `).join("")}
    </div>
  </section>
  <section class="month-banner">
    <div class="eyebrow">CURRENT THEME</div>
    <h2>${months[state.theme]} ${decorations[state.theme]}</h2>
    <p class="muted">Your Bloom colors will follow this monthly selection</p>
  </section>`;
}
function historyMarkup() {
  if(!state.history.length) return `<p class="muted">Your completed days will appear here after you save them.</p>`;
  return state.history.map(h=>`
    <div class="history">
      <strong>${escapeHTML(h.date)}</strong>
      <div class="muted">${h.done} of ${h.total} routine tasks completed · ${h.percent}%</div>
    </div>`).join("");
}
function render() {
  document.getElementById("today").textContent=new Date().toLocaleDateString(undefined,{weekday:"short",month:"short",day:"numeric"});
  document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("active",b.dataset.tab===state.tab));
  const views={Home:home,Routines:routines,Cleaning:cleaning,Calendar:calendar,Themes:themes};
  document.getElementById("app").innerHTML=(views[state.tab]||home)();
}
function changeTab(tab) {
  state.tab=tab;save();render();
}
document.addEventListener("click",e=>{
  const nav=e.target.closest("[data-tab]");
  if(nav){changeTab(nav.dataset.tab);return;}
  const go=e.target.closest("[data-go]");
  if(go){changeTab(go.dataset.go);return;}
  const theme=e.target.closest("[data-theme]");
  if(theme){state.theme=Number(theme.dataset.theme);save();render();return;}
  const check=e.target.closest("[data-check]");
  if(check){
    const id=Number(check.dataset.id);
    const type=check.dataset.check;
    let items;
    if(type==="routine") items=routineForDate();
    if(type==="daily") items=cleaningForDate();
    if(type==="room") items=state.cleaning[state.selectedDate+"-room"]||[];
    const item=items.find(x=>x.id===id);
    if(item)item.done=!item.done;
    save();render();return;
  }
  if(e.target.closest("[data-archive]")) {
    const items=routineForDate();
    const done=items.filter(x=>x.done).length;
    const date=selectedDate().toLocaleDateString(undefined,{month:"long",day:"numeric",year:"numeric"});
    state.history=state.history.filter(x=>x.key!==state.selectedDate);
    state.history.unshift({key:state.selectedDate,date,done,total:items.length,percent:Math.round(done/items.length*100)});
    save();render();return;
  }
  const remove=e.target.closest("[data-delete-event]");
  if(remove){
    state.events=state.events.filter(x=>String(x.id)!==remove.dataset.deleteEvent);
    save();render();
  }
});
document.addEventListener("change",e=>{
  if(["routineDate","cleanDate","calendarDate"].includes(e.target.id)){
    state.selectedDate=e.target.value||localDateKey(new Date());
    save();render();
  }
});
document.addEventListener("submit",e=>{
  if(e.target.id==="eventForm"){
    e.preventDefault();
    const title=document.getElementById("eventTitle").value.trim();
    const date=document.getElementById("eventDate").value;
    const time=document.getElementById("eventTime").value.trim()||"Time not set";
    if(!title||!date)return;
    state.events.push({id:Date.now(),title,date,time});
    state.selectedDate=date;
    save();render();
  }
});
load();
if(!months[state.theme]) state.theme=new Date().getMonth();
render();
</script>
</body>
</html>

